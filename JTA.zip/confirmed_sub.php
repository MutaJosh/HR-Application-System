<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

    <link rel="stylesheet" href="./css/main.css">
    <title>Job Request Tracking System</title>
</head>
<body>
    
<div class="container register">
                <!-- Left Pane (Admin-Login) -->
                <div class="row">
                    <div class="col-md-4"></div>
                    <div class="col-md-4 register-left">
                        <img src="./moh_logo.jpg" alt=""/>
                        <h3>Congrats!</h3>
                        <i>You successfully submitted the application!</i> <br><br>
                        <a class="btn btn-light" type="button" href="./">Homek</a><br/>
                    </div>
                    <!-- <div class="col-md-9 register-right">


                        <div class="tab-content" id="myTabContent">
                            <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
                                <h3 class="register-heading">Apply as a Employee</h3>
                            </div>
                                
                        
                        </div>
                    </div> -->
                </div>

</div>

</body>
</html>
