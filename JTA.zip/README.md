# HR Application System 

This is to help the Organisation HR Department manage the application process easily on their own servers. 

Note: It is dedicated for Health Sector Organisations (MoH, ...)

Designed & Developed by Josue Mutabazi
